# cannabisnew

1. Download Files
2. Open index.html
3. Search what you need to edit e.g. Germany. Search Germany
4. Edit and save 
5. Open index.html in browser in order to check your edits.
